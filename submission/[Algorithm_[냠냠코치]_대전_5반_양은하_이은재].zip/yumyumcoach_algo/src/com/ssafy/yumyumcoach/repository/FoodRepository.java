package com.ssafy.yumyumcoach.repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.ssafy.yumyumcoach.domain.Food;

public class FoodRepository {
    private final Map<Integer, Food> foodMap = new LinkedHashMap<>();

    public void save(Food food) {
        foodMap.put(food.getFoodId(), food);
    }

    public Food findById(int foodId) {
        return foodMap.get(foodId);
    }

    public List<Food> findAll() {
        return new ArrayList<>(foodMap.values());
    }
}
