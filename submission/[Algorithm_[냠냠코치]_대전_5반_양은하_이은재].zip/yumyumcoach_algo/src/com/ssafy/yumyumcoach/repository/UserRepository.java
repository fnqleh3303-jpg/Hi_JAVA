package com.ssafy.yumyumcoach.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ssafy.yumyumcoach.domain.User;

public class UserRepository {
    private final Map<String, User> userMap = new HashMap<>();

    public boolean existsById(String userId) {
        return userMap.containsKey(userId);
    }

    public void save(User user) {
        userMap.put(user.getUserId(), user);
    }

    public User findById(String userId) {
        return userMap.get(userId);
    }

    public List<User> findAll() {
        return new ArrayList<>(userMap.values());
    }
}
