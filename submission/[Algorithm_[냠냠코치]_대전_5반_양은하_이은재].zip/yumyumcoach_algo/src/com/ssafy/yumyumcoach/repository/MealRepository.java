package com.ssafy.yumyumcoach.repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.ssafy.yumyumcoach.domain.MealRecord;

public class MealRepository {
    private final Map<Integer, MealRecord> mealMap = new LinkedHashMap<>();

    public void save(MealRecord mealRecord) {
        mealMap.put(mealRecord.getMealId(), mealRecord);
    }

    public MealRecord findById(int mealId) {
        return mealMap.get(mealId);
    }

    public List<MealRecord> findAll() {
        return new ArrayList<>(mealMap.values());
    }

    public void delete(int mealId) {
        mealMap.remove(mealId);
    }
}
