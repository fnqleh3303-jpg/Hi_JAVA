package com.ssafy.yumyumcoach.repository;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.yumyumcoach.domain.CommunityPost;

public class CommunityRepository {
    private final List<CommunityPost> posts = new ArrayList<>();

    public void save(CommunityPost post) {
        posts.add(post);
    }

    public List<CommunityPost> findAll() {
        return new ArrayList<>(posts);
    }
}
