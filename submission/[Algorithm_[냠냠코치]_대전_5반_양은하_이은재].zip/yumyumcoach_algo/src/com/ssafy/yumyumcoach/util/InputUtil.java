package com.ssafy.yumyumcoach.util;

import java.util.Scanner;

public class InputUtil {
    private final Scanner sc;

    public InputUtil(Scanner sc) {
        this.sc = sc;
    }

    public String readLine(String message) {
        System.out.print(message);
        return sc.nextLine().trim();
    }

    public int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("숫자를 입력해주세요.");
            }
        }
    }

    public double readDouble(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Double.parseDouble(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("숫자를 입력해주세요.");
            }
        }
    }
}
