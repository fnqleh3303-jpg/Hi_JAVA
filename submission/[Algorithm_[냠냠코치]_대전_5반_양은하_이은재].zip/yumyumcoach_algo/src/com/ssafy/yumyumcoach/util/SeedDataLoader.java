package com.ssafy.yumyumcoach.util;

import java.util.Arrays;

import com.ssafy.yumyumcoach.domain.CommunityPost;
import com.ssafy.yumyumcoach.domain.Food;
import com.ssafy.yumyumcoach.domain.GoalType;
import com.ssafy.yumyumcoach.domain.MealItem;
import com.ssafy.yumyumcoach.domain.MealRecord;
import com.ssafy.yumyumcoach.domain.User;
import com.ssafy.yumyumcoach.repository.CommunityRepository;
import com.ssafy.yumyumcoach.repository.FoodRepository;
import com.ssafy.yumyumcoach.repository.MealRepository;
import com.ssafy.yumyumcoach.repository.UserRepository;

public class SeedDataLoader {
    public static void load(UserRepository userRepository, FoodRepository foodRepository, MealRepository mealRepository,
            CommunityRepository communityRepository, IdGenerator idGenerator) {
        userRepository.save(new User("sample", "1234", "샘플유저", 170, 65, GoalType.BALANCE));
        userRepository.save(new User("coach", "1234", "코치", 175, 72, GoalType.DIET));

        saveFoods(foodRepository);
        saveMeals(foodRepository, mealRepository, idGenerator);
        saveCommunity(communityRepository);
    }

    private static void saveFoods(FoodRepository repo) {
        repo.save(new Food(1, "현미밥", 300, 6, 65, 1));
        repo.save(new Food(2, "계란찜", 150, 12, 1, 10));
        repo.save(new Food(3, "시금치나물", 50, 3, 8, 0));
        repo.save(new Food(4, "닭가슴살 샐러드", 350, 35, 15, 12));
        repo.save(new Food(5, "고구마", 200, 2, 45, 0));
        repo.save(new Food(6, "연어 구이", 400, 40, 0, 25));
        repo.save(new Food(7, "브로콜리", 50, 3, 10, 0));
        repo.save(new Food(8, "오트밀", 250, 8, 45, 5));
        repo.save(new Food(9, "바나나", 100, 1, 25, 0));
        repo.save(new Food(10, "그릭요거트", 150, 15, 8, 5));
        repo.save(new Food(11, "비빔밥", 550, 20, 90, 15));
        repo.save(new Food(12, "미역국", 100, 5, 10, 3));
        repo.save(new Food(13, "두부조림", 200, 15, 5, 12));
        repo.save(new Food(14, "잡곡밥", 300, 6, 65, 1));
        repo.save(new Food(15, "콩나물무침", 50, 3, 8, 0));
        repo.save(new Food(16, "토스트", 200, 5, 35, 5));
        repo.save(new Food(17, "스크램블 에그", 180, 12, 1, 13));
        repo.save(new Food(18, "아보카도", 160, 2, 8, 15));
        repo.save(new Food(19, "샐러드", 300, 20, 25, 15));
        repo.save(new Food(20, "통밀빵", 150, 5, 25, 3));
        repo.save(new Food(21, "불고기", 450, 35, 30, 20));
        repo.save(new Food(22, "쌀밥", 300, 6, 65, 1));
        repo.save(new Food(23, "김치", 50, 2, 8, 0));
        repo.save(new Food(24, "고구마샐러드", 220, 4, 38, 5));
        repo.save(new Food(25, "바나나스무디", 180, 4, 35, 2));
    }

    private static void saveMeals(FoodRepository repo, MealRepository mealRepository, IdGenerator idGenerator) {
        mealRepository.save(new MealRecord(1, "sample", "2025-05-15", "아침",
                Arrays.asList(new MealItem(repo.findById(1), 1), new MealItem(repo.findById(2), 1),
                        new MealItem(repo.findById(3), 1))));
        mealRepository.save(new MealRecord(2, "sample", "2024-03-15", "점심",
                Arrays.asList(new MealItem(repo.findById(4), 1), new MealItem(repo.findById(5), 1))));
        mealRepository.save(new MealRecord(3, "sample", "2024-03-15", "저녁",
                Arrays.asList(new MealItem(repo.findById(6), 1), new MealItem(repo.findById(7), 1),
                        new MealItem(repo.findById(1), 1))));
        mealRepository.save(new MealRecord(4, "sample", "2024-03-14", "아침",
                Arrays.asList(new MealItem(repo.findById(8), 1), new MealItem(repo.findById(9), 1),
                        new MealItem(repo.findById(10), 1))));
        mealRepository.save(new MealRecord(5, "sample", "2024-03-14", "점심",
                Arrays.asList(new MealItem(repo.findById(11), 1), new MealItem(repo.findById(12), 1))));
        mealRepository.save(new MealRecord(6, "sample", "2024-03-14", "저녁",
                Arrays.asList(new MealItem(repo.findById(13), 1), new MealItem(repo.findById(14), 1),
                        new MealItem(repo.findById(15), 1))));
        mealRepository.save(new MealRecord(7, "coach", "2024-03-13", "아침",
                Arrays.asList(new MealItem(repo.findById(16), 1), new MealItem(repo.findById(17), 1),
                        new MealItem(repo.findById(18), 1))));
        mealRepository.save(new MealRecord(8, "coach", "2024-03-13", "점심",
                Arrays.asList(new MealItem(repo.findById(19), 1), new MealItem(repo.findById(20), 1))));
        mealRepository.save(new MealRecord(9, "coach", "2024-03-13", "저녁",
                Arrays.asList(new MealItem(repo.findById(21), 1), new MealItem(repo.findById(22), 1),
                        new MealItem(repo.findById(23), 1))));
        mealRepository.save(new MealRecord(10, "sample", "2024-03-12", "간식",
                Arrays.asList(new MealItem(repo.findById(24), 1), new MealItem(repo.findById(25), 1))));
        idGenerator.syncMealSequence(10);
    }

    private static void saveCommunity(CommunityRepository communityRepository) {
        communityRepository.save(new CommunityPost(1, "단백질 보충제 추천해주세요",
                "운동을 시작한 지 3개월이 되었는데, 단백질 보충제를 찾고 있습니다. 추천해주실 만한 제품이 있을까요?", "김철수",
                "2024-03-20", "질문"));
        communityRepository.save(new CommunityPost(2, "식단 관리 꿀팁 공유합니다",
                "1년 동안 식단 관리를 하면서 알게 된 꿀팁들을 공유합니다. 아침 식사는 꼭 하기, 물을 충분히 마시기, 야채를 먼저 먹기",
                "이영희", "2024-03-19", "정보"));
        communityRepository.save(new CommunityPost(3, "오늘의 식단 공유합니다",
                "아침: 오트밀 + 바나나 + 그릭요거트 / 점심: 닭가슴살 샐러드 + 고구마 / 저녁: 연어 구이 + 브로콜리 + 현미밥", "박지민",
                "2024-03-18", "식단"));
    }
}
