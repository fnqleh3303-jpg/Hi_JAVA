package com.ssafy.yumyumcoach.util;

import java.util.LinkedHashMap;
import java.util.Map;

import com.ssafy.yumyumcoach.algorithms.BruteForceMatcher;

public class MenuCommandResolver {
    public static int resolve(String input, Map<Integer, String[]> options) {
        if (input == null || input.isEmpty()) {
            return Integer.MIN_VALUE;
        }
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException ignored) {
        }

        String normalized = input.replaceAll("\\s+", "");
        for (Map.Entry<Integer, String[]> entry : options.entrySet()) {
            for (String alias : entry.getValue()) {
                String key = alias.replaceAll("\\s+", "");
                if (normalized.equalsIgnoreCase(key)
                        || BruteForceMatcher.contains(normalized, key)
                        || BruteForceMatcher.contains(key, normalized)) {
                    return entry.getKey();
                }
            }
        }
        return Integer.MIN_VALUE;
    }

    public static Map<Integer, String[]> mainMenuBeforeLogin() {
        Map<Integer, String[]> map = new LinkedHashMap<>();
        map.put(1, new String[] { "회원가입" });
        map.put(2, new String[] { "로그인" });
        map.put(3, new String[] { "음식검색", "음식db검색" });
        map.put(4, new String[] { "커뮤니티검색", "게시글검색" });
        map.put(0, new String[] { "종료" });
        return map;
    }

    public static Map<Integer, String[]> mainMenuAfterLogin() {
        Map<Integer, String[]> map = new LinkedHashMap<>();
        map.put(1, new String[] { "회원관리", "내정보" });
        map.put(2, new String[] { "식단관리" });
        map.put(3, new String[] { "음식검색", "음식db검색" });
        map.put(4, new String[] { "커뮤니티검색", "게시글검색" });
        map.put(5, new String[] { "로그아웃" });
        map.put(0, new String[] { "종료" });
        return map;
    }

    public static Map<Integer, String[]> userMenu() {
        Map<Integer, String[]> map = new LinkedHashMap<>();
        map.put(1, new String[] { "조회", "내정보조회" });
        map.put(2, new String[] { "수정", "회원수정" });
        map.put(3, new String[] { "탈퇴", "회원탈퇴" });
        map.put(0, new String[] { "뒤로가기" });
        return map;
    }

    public static Map<Integer, String[]> mealMenu() {
        Map<Integer, String[]> map = new LinkedHashMap<>();
        map.put(1, new String[] { "식단작성" });
        map.put(2, new String[] { "식단전체조회" });
        map.put(3, new String[] { "식단상세조회" });
        map.put(4, new String[] { "식단수정" });
        map.put(5, new String[] { "식단삭제" });
        map.put(6, new String[] { "식단분석" });
        map.put(7, new String[] { "식단검색", "키워드검색" });
        map.put(0, new String[] { "뒤로가기" });
        return map;
    }
}
