package com.ssafy.yumyumcoach.util;

public class IdGenerator {
    private int mealSeq = 100;

    public int nextMealId() {
        return mealSeq++;
    }

    public void syncMealSequence(int usedId) {
        if (mealSeq <= usedId) {
            mealSeq = usedId + 1;
        }
    }
}
