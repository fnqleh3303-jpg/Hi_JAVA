package com.ssafy.yumyumcoach;

import java.util.Scanner;

import com.ssafy.yumyumcoach.manager.AnalysisManager;
import com.ssafy.yumyumcoach.manager.AuthManager;
import com.ssafy.yumyumcoach.manager.CommunityManager;
import com.ssafy.yumyumcoach.manager.FoodSearchManager;
import com.ssafy.yumyumcoach.manager.MealManager;
import com.ssafy.yumyumcoach.manager.UserManager;
import com.ssafy.yumyumcoach.repository.CommunityRepository;
import com.ssafy.yumyumcoach.repository.FoodRepository;
import com.ssafy.yumyumcoach.repository.MealRepository;
import com.ssafy.yumyumcoach.repository.UserRepository;
import com.ssafy.yumyumcoach.ui.MainMenu;
import com.ssafy.yumyumcoach.ui.MealMenu;
import com.ssafy.yumyumcoach.ui.UserMenu;
import com.ssafy.yumyumcoach.util.IdGenerator;
import com.ssafy.yumyumcoach.util.InputUtil;
import com.ssafy.yumyumcoach.util.SeedDataLoader;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        InputUtil inputUtil = new InputUtil(sc);
        IdGenerator idGenerator = new IdGenerator();

        UserRepository userRepository = new UserRepository();
        FoodRepository foodRepository = new FoodRepository();
        MealRepository mealRepository = new MealRepository();
        CommunityRepository communityRepository = new CommunityRepository();

        SeedDataLoader.load(userRepository, foodRepository, mealRepository, communityRepository, idGenerator);

        AuthManager authManager = new AuthManager(userRepository);
        UserManager userManager = new UserManager(userRepository);
        MealManager mealManager = new MealManager(mealRepository, idGenerator);
        AnalysisManager analysisManager = new AnalysisManager();
        FoodSearchManager foodSearchManager = new FoodSearchManager(foodRepository);
        CommunityManager communityManager = new CommunityManager(communityRepository);

        UserMenu userMenu = new UserMenu(inputUtil, authManager, userManager);
        MealMenu mealMenu = new MealMenu(inputUtil, mealManager, foodRepository, authManager, analysisManager);
        MainMenu mainMenu = new MainMenu(inputUtil, authManager, userManager, mealMenu, userMenu, foodSearchManager,
                communityManager);

        System.out.println("샘플 계정: sample / 1234");
        System.out.println("샘플 계정: coach / 1234");
        System.out.println("샘플 식단 데이터가 미리 로드되어 있습니다.");
        mainMenu.run();
        sc.close();
    }
}
