package com.ssafy.yumyumcoach.ui;

import java.util.List;

import com.ssafy.yumyumcoach.domain.CommunityPost;
import com.ssafy.yumyumcoach.domain.Food;
import com.ssafy.yumyumcoach.domain.GoalType;
import com.ssafy.yumyumcoach.domain.User;
import com.ssafy.yumyumcoach.manager.AuthManager;
import com.ssafy.yumyumcoach.manager.CommunityManager;
import com.ssafy.yumyumcoach.manager.FoodSearchManager;
import com.ssafy.yumyumcoach.manager.UserManager;
import com.ssafy.yumyumcoach.util.InputUtil;
import com.ssafy.yumyumcoach.util.MenuCommandResolver;

public class MainMenu {
    private final InputUtil inputUtil;
    private final AuthManager authManager;
    private final UserManager userManager;
    private final MealMenu mealMenu;
    private final UserMenu userMenu;
    private final FoodSearchManager foodSearchManager;
    private final CommunityManager communityManager;

    public MainMenu(InputUtil inputUtil, AuthManager authManager, UserManager userManager, MealMenu mealMenu,
            UserMenu userMenu, FoodSearchManager foodSearchManager, CommunityManager communityManager) {
        this.inputUtil = inputUtil;
        this.authManager = authManager;
        this.userManager = userManager;
        this.mealMenu = mealMenu;
        this.userMenu = userMenu;
        this.foodSearchManager = foodSearchManager;
        this.communityManager = communityManager;
    }

    public void run() {
        while (true) {
            printMenu();
            String raw = inputUtil.readLine("선택: ");
            int choice = authManager.isLogin()
                    ? MenuCommandResolver.resolve(raw, MenuCommandResolver.mainMenuAfterLogin())
                    : MenuCommandResolver.resolve(raw, MenuCommandResolver.mainMenuBeforeLogin());

            if (!authManager.isLogin()) {
                if (choice == 1) register();
                else if (choice == 2) login();
                else if (choice == 3) searchFoods();
                else if (choice == 4) searchCommunity();
                else if (choice == 0) { System.out.println("프로그램을 종료합니다."); return; }
                else System.out.println("올바른 메뉴를 입력해주세요.");
            } else {
                if (choice == 1) userMenu.run();
                else if (choice == 2) mealMenu.run();
                else if (choice == 3) searchFoods();
                else if (choice == 4) searchCommunity();
                else if (choice == 5) { authManager.logout(); System.out.println("로그아웃되었습니다."); }
                else if (choice == 0) { System.out.println("프로그램을 종료합니다."); return; }
                else System.out.println("올바른 메뉴를 입력해주세요.");
            }
        }
    }

    private void printMenu() {
        if (!authManager.isLogin()) {
            System.out.println("\n=== YumYumCoach ===");
            System.out.println("1. 회원가입");
            System.out.println("2. 로그인");
            System.out.println("3. 음식 DB 검색(Boyer-Moore)");
            System.out.println("4. 커뮤니티 검색(Rabin-Karp)");
            System.out.println("0. 종료");
        } else {
            System.out.println("\n=== YumYumCoach (로그인: " + authManager.getLoginUser().getUserId() + ") ===");
            System.out.println("1. 회원 관리");
            System.out.println("2. 식단 관리");
            System.out.println("3. 음식 DB 검색(Boyer-Moore)");
            System.out.println("4. 커뮤니티 검색(Rabin-Karp)");
            System.out.println("5. 로그아웃");
            System.out.println("0. 종료");
        }
    }

    private void register() {
        String userId = inputUtil.readLine("아이디: ");
        String password = inputUtil.readLine("비밀번호: ");
        String name = inputUtil.readLine("이름: ");
        double height = inputUtil.readDouble("키(cm): ");
        double weight = inputUtil.readDouble("몸무게(kg): ");
        System.out.println("목표 선택: 1. 다이어트 2. 균형식 3. 벌크업");
        GoalType goal = GoalType.fromNumber(inputUtil.readInt("선택: "));
        boolean ok = userManager.register(new User(userId, password, name, height, weight, goal));
        System.out.println(ok ? "회원가입 성공" : "이미 존재하는 아이디입니다.");
    }

    private void login() {
        String userId = inputUtil.readLine("아이디: ");
        String password = inputUtil.readLine("비밀번호: ");
        boolean ok = authManager.login(userId, password);
        System.out.println(ok ? "로그인 성공" : "로그인 실패");
    }

    private void searchFoods() {
        String keyword = inputUtil.readLine("음식 검색어 입력: ");
        List<Food> result = foodSearchManager.searchFoods(keyword);
        if (result.isEmpty()) {
            System.out.println("검색 결과가 없습니다.");
            return;
        }
        System.out.println("\n[Boyer-Moore 음식 검색 결과]");
        result.forEach(System.out::println);
    }

    private void searchCommunity() {
        String keyword = inputUtil.readLine("게시글 검색어 입력: ");
        List<CommunityPost> result = communityManager.searchPosts(keyword);
        if (result.isEmpty()) {
            System.out.println("검색 결과가 없습니다.");
            return;
        }
        System.out.println("\n[Rabin-Karp 커뮤니티 검색 결과]");
        for (CommunityPost post : result) {
            System.out.println(post);
            System.out.println("내용: " + post.getContent());
            System.out.println("----------------------------");
        }
    }
}
