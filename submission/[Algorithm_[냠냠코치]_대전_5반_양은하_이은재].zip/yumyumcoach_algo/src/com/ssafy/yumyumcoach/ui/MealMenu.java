package com.ssafy.yumyumcoach.ui;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.yumyumcoach.domain.MealItem;
import com.ssafy.yumyumcoach.domain.MealRecord;
import com.ssafy.yumyumcoach.domain.User;
import com.ssafy.yumyumcoach.manager.AnalysisManager;
import com.ssafy.yumyumcoach.manager.AuthManager;
import com.ssafy.yumyumcoach.manager.MealManager;
import com.ssafy.yumyumcoach.repository.FoodRepository;
import com.ssafy.yumyumcoach.util.InputUtil;
import com.ssafy.yumyumcoach.util.MenuCommandResolver;

public class MealMenu {
    private final InputUtil inputUtil;
    private final MealManager mealManager;
    private final FoodRepository foodRepository;
    private final AuthManager authManager;
    private final AnalysisManager analysisManager;

    public MealMenu(InputUtil inputUtil, MealManager mealManager, FoodRepository foodRepository, AuthManager authManager,
            AnalysisManager analysisManager) {
        this.inputUtil = inputUtil;
        this.mealManager = mealManager;
        this.foodRepository = foodRepository;
        this.authManager = authManager;
        this.analysisManager = analysisManager;
    }

    public void run() {
        while (true) {
            System.out.println("\n[식단 관리]");
            System.out.println("1. 식단 작성");
            System.out.println("2. 식단 전체 조회");
            System.out.println("3. 식단 상세 조회");
            System.out.println("4. 식단 수정");
            System.out.println("5. 식단 삭제");
            System.out.println("6. 식단 분석");
            System.out.println("7. 키워드 검색(KMP)");
            System.out.println("0. 뒤로가기");
            String raw = inputUtil.readLine("선택: ");
            int choice = MenuCommandResolver.resolve(raw, MenuCommandResolver.mealMenu());
            switch (choice) {
                case 1: createMeal(); break;
                case 2: printAllMeals(); break;
                case 3: printDetail(); break;
                case 4: updateMeal(); break;
                case 5: deleteMeal(); break;
                case 6: analyzeMeal(); break;
                case 7: searchMeal(); break;
                case 0: return;
                default: System.out.println("올바른 메뉴를 입력해주세요.");
            }
        }
    }

    private List<MealItem> readMealItems() {
        List<MealItem> items = new ArrayList<>();
        while (true) {
            System.out.println("\n[음식 목록]");
            foodRepository.findAll().forEach(System.out::println);
            int foodId = inputUtil.readInt("추가할 음식 ID(종료: 0): ");
            if (foodId == 0) break;
            if (foodRepository.findById(foodId) == null) {
                System.out.println("존재하지 않는 음식입니다.");
                continue;
            }
            int qty = inputUtil.readInt("수량: ");
            items.add(new MealItem(foodRepository.findById(foodId), qty));
        }
        return items;
    }

    private void createMeal() {
        String date = inputUtil.readLine("날짜(YYYY-MM-DD): ");
        String type = inputUtil.readLine("식사구분(아침/점심/저녁/간식): ");
        List<MealItem> items = readMealItems();
        if (items.isEmpty()) {
            System.out.println("음식이 1개 이상 필요합니다.");
            return;
        }
        MealRecord meal = mealManager.createMeal(authManager.getLoginUser().getUserId(), date, type, items);
        System.out.println("식단이 등록되었습니다. 식단 ID: " + meal.getMealId());
    }

    private void printAllMeals() {
        List<MealRecord> meals = mealManager.findAll();
        if (meals.isEmpty()) {
            System.out.println("등록된 식단이 없습니다.");
            return;
        }
        meals.forEach(System.out::println);
    }

    private void printDetail() {
        int mealId = inputUtil.readInt("식단 ID: ");
        MealRecord meal = mealManager.findById(mealId);
        if (meal == null) {
            System.out.println("해당 식단이 없습니다.");
            return;
        }
        printMealDetail(meal);
    }

    private void updateMeal() {
        int mealId = inputUtil.readInt("수정할 식단 ID: ");
        String date = inputUtil.readLine("새 날짜(YYYY-MM-DD): ");
        String type = inputUtil.readLine("새 식사구분: ");
        List<MealItem> items = readMealItems();
        if (items.isEmpty()) {
            System.out.println("음식이 1개 이상 필요합니다.");
            return;
        }
        boolean ok = mealManager.updateMeal(mealId, authManager.getLoginUser().getUserId(), date, type, items);
        System.out.println(ok ? "식단이 수정되었습니다." : "본인 식단만 수정할 수 있습니다.");
    }

    private void deleteMeal() {
        int mealId = inputUtil.readInt("삭제할 식단 ID: ");
        boolean ok = mealManager.deleteMeal(mealId, authManager.getLoginUser().getUserId());
        System.out.println(ok ? "식단이 삭제되었습니다." : "본인 식단만 삭제할 수 있습니다.");
    }

    private void analyzeMeal() {
        int mealId = inputUtil.readInt("분석할 식단 ID: ");
        MealRecord meal = mealManager.findById(mealId);
        if (meal == null) {
            System.out.println("해당 식단이 없습니다.");
            return;
        }
        User user = authManager.getLoginUser();
        System.out.println(analysisManager.analyze(meal, user));
    }

    private void searchMeal() {
        String keyword = inputUtil.readLine("검색어 입력: ");
        List<MealRecord> result = mealManager.searchMealsByKeyword(keyword);
        if (result.isEmpty()) {
            System.out.println("검색 결과가 없습니다.");
            return;
        }
        System.out.println("\n[KMP 검색 결과]");
        for (MealRecord meal : result) {
            printMealDetail(meal);
            System.out.println("----------------------------");
        }
    }

    private void printMealDetail(MealRecord meal) {
        System.out.println(meal);
        for (MealItem item : meal.getItems()) {
            System.out.println(" - " + item + String.format(" [kcal %.0f]", item.getTotalCalories()));
        }
    }
}
