package com.ssafy.yumyumcoach.ui;

import java.util.Map;

import com.ssafy.yumyumcoach.domain.GoalType;
import com.ssafy.yumyumcoach.domain.User;
import com.ssafy.yumyumcoach.manager.AuthManager;
import com.ssafy.yumyumcoach.manager.UserManager;
import com.ssafy.yumyumcoach.util.InputUtil;
import com.ssafy.yumyumcoach.util.MenuCommandResolver;

public class UserMenu {
    private final InputUtil inputUtil;
    private final AuthManager authManager;
    private final UserManager userManager;

    public UserMenu(InputUtil inputUtil, AuthManager authManager, UserManager userManager) {
        this.inputUtil = inputUtil;
        this.authManager = authManager;
        this.userManager = userManager;
    }

    public void run() {
        while (true) {
            System.out.println("\n[회원 관리]");
            System.out.println("1. 내 정보 조회");
            System.out.println("2. 내 정보 수정");
            System.out.println("3. 회원 탈퇴");
            System.out.println("0. 뒤로가기");
            String raw = inputUtil.readLine("선택: ");
            int choice = MenuCommandResolver.resolve(raw, MenuCommandResolver.userMenu());
            if (choice == 1) {
                System.out.println(authManager.getLoginUser());
            } else if (choice == 2) {
                updateInfo();
            } else if (choice == 3) {
                User user = authManager.getLoginUser();
                userManager.deactivate(user);
                authManager.logout();
                System.out.println("회원 탈퇴가 완료되었습니다.");
                return;
            } else if (choice == 0) {
                return;
            } else {
                System.out.println("올바른 메뉴를 입력해주세요.");
            }
        }
    }

    private void updateInfo() {
        User user = authManager.getLoginUser();
        String password = inputUtil.readLine("새 비밀번호: ");
        String name = inputUtil.readLine("새 이름: ");
        double height = inputUtil.readDouble("새 키(cm): ");
        double weight = inputUtil.readDouble("새 몸무게(kg): ");
        GoalType goalType = readGoalType();
        userManager.updateMyInfo(user, password, name, height, weight, goalType);
        System.out.println("회원 정보가 수정되었습니다.");
    }

    private GoalType readGoalType() {
        System.out.println("목표 선택: 1. 다이어트 2. 균형식 3. 벌크업");
        int g = inputUtil.readInt("선택: ");
        return GoalType.fromNumber(g);
    }
}
