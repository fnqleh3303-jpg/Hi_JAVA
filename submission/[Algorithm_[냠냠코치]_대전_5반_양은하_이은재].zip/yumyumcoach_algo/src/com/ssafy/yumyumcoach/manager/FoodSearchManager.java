package com.ssafy.yumyumcoach.manager;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.yumyumcoach.algorithms.BoyerMooreMatcher;
import com.ssafy.yumyumcoach.domain.Food;
import com.ssafy.yumyumcoach.repository.FoodRepository;

public class FoodSearchManager {
    private final FoodRepository foodRepository;

    public FoodSearchManager(FoodRepository foodRepository) {
        this.foodRepository = foodRepository;
    }

    public List<Food> searchFoods(String keyword) {
        String pattern = keyword.toLowerCase();
        List<Food> result = new ArrayList<>();
        for (Food food : foodRepository.findAll()) {
            if (BoyerMooreMatcher.contains(food.getFoodName().toLowerCase(), pattern)) {
                result.add(food);
            }
        }
        return result;
    }
}
