package com.ssafy.yumyumcoach.manager;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.yumyumcoach.algorithms.RabinKarpMatcher;
import com.ssafy.yumyumcoach.domain.CommunityPost;
import com.ssafy.yumyumcoach.repository.CommunityRepository;

public class CommunityManager {
    private final CommunityRepository communityRepository;

    public CommunityManager(CommunityRepository communityRepository) {
        this.communityRepository = communityRepository;
    }

    public List<CommunityPost> searchPosts(String keyword) {
        String pattern = keyword.toLowerCase();
        List<CommunityPost> result = new ArrayList<>();
        for (CommunityPost post : communityRepository.findAll()) {
            String text = (post.getTitle() + " " + post.getContent()).toLowerCase();
            if (RabinKarpMatcher.contains(text, pattern)) {
                result.add(post);
            }
        }
        return result;
    }
}
