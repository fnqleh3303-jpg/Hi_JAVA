package com.ssafy.yumyumcoach.manager;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.yumyumcoach.algorithms.KMPMatcher;
import com.ssafy.yumyumcoach.domain.MealItem;
import com.ssafy.yumyumcoach.domain.MealRecord;
import com.ssafy.yumyumcoach.repository.MealRepository;
import com.ssafy.yumyumcoach.util.IdGenerator;

public class MealManager {
    private final MealRepository mealRepository;
    private final IdGenerator idGenerator;

    public MealManager(MealRepository mealRepository, IdGenerator idGenerator) {
        this.mealRepository = mealRepository;
        this.idGenerator = idGenerator;
    }

    public MealRecord createMeal(String userId, String date, String mealType, List<MealItem> items) {
        MealRecord meal = new MealRecord(idGenerator.nextMealId(), userId, date, mealType, items);
        mealRepository.save(meal);
        return meal;
    }

    public List<MealRecord> findAll() {
        return mealRepository.findAll();
    }

    public MealRecord findById(int mealId) {
        return mealRepository.findById(mealId);
    }

    public boolean updateMeal(int mealId, String userId, String date, String mealType, List<MealItem> items) {
        MealRecord meal = mealRepository.findById(mealId);
        if (meal == null || !meal.getUserId().equals(userId)) return false;
        meal.setDate(date);
        meal.setMealType(mealType);
        meal.setItems(items);
        return true;
    }

    public boolean deleteMeal(int mealId, String userId) {
        MealRecord meal = mealRepository.findById(mealId);
        if (meal == null || !meal.getUserId().equals(userId)) return false;
        mealRepository.delete(mealId);
        return true;
    }

    public List<MealRecord> searchMealsByKeyword(String keyword) {
        String pattern = keyword.toLowerCase();
        List<MealRecord> result = new ArrayList<>();
        for (MealRecord meal : mealRepository.findAll()) {
            boolean matched = false;
            for (MealItem item : meal.getItems()) {
                String foodName = item.getFood().getFoodName().toLowerCase();
                if (KMPMatcher.contains(foodName, pattern)) {
                    matched = true;
                    break;
                }
            }
            if (matched) {
                result.add(meal);
            }
        }
        return result;
    }
}
