package com.ssafy.yumyumcoach.manager;

import com.ssafy.yumyumcoach.domain.User;
import com.ssafy.yumyumcoach.repository.UserRepository;

public class AuthManager {
    private final UserRepository userRepository;
    private User loginUser;

    public AuthManager(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public boolean login(String userId, String password) {
        User user = userRepository.findById(userId);
        if (user == null || !user.isActive()) return false;
        if (!user.getPassword().equals(password)) return false;
        loginUser = user;
        return true;
    }

    public void logout() { loginUser = null; }
    public boolean isLogin() { return loginUser != null; }
    public User getLoginUser() { return loginUser; }
}
