package com.ssafy.yumyumcoach.manager;

import com.ssafy.yumyumcoach.domain.GoalType;
import com.ssafy.yumyumcoach.domain.User;
import com.ssafy.yumyumcoach.repository.UserRepository;

public class UserManager {
    private final UserRepository userRepository;

    public UserManager(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public boolean register(User user) {
        if (userRepository.existsById(user.getUserId())) return false;
        userRepository.save(user);
        return true;
    }

    public boolean updateMyInfo(User user, String password, String name, double height, double weight, GoalType goalType) {
        user.setPassword(password);
        user.setName(name);
        user.setHeight(height);
        user.setWeight(weight);
        user.setGoalType(goalType);
        return true;
    }

    public boolean deactivate(User user) {
        user.setActive(false);
        return true;
    }
}
