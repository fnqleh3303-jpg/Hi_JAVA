package com.ssafy.yumyumcoach.manager;

import com.ssafy.yumyumcoach.domain.AnalysisResult;
import com.ssafy.yumyumcoach.domain.GoalType;
import com.ssafy.yumyumcoach.domain.MealItem;
import com.ssafy.yumyumcoach.domain.MealRecord;
import com.ssafy.yumyumcoach.domain.User;

public class AnalysisManager {
    public AnalysisResult analyze(MealRecord mealRecord, User user) {
        double calories = 0, protein = 0, carbs = 0, fat = 0;
        for (MealItem item : mealRecord.getItems()) {
            calories += item.getTotalCalories();
            protein += item.getTotalProtein();
            carbs += item.getTotalCarbs();
            fat += item.getTotalFat();
        }

        double targetCalories;
        double targetProtein;
        double targetCarbs;
        double targetFat;

        GoalType goal = user.getGoalType();
        if (goal == GoalType.DIET) {
            targetCalories = 600; targetProtein = 35; targetCarbs = 70; targetFat = 20;
        } else if (goal == GoalType.BULKUP) {
            targetCalories = 1000; targetProtein = 45; targetCarbs = 120; targetFat = 30;
        } else {
            targetCalories = 800; targetProtein = 30; targetCarbs = 90; targetFat = 25;
        }

        int score = (int) Math.round((
                scoreOne(calories, targetCalories, 0.10) +
                scoreOne(protein, targetProtein, 1.0) +
                scoreOne(carbs, targetCarbs, 0.50) +
                scoreOne(fat, targetFat, 0.80)) / 4.0);

        String comment;
        if (score >= 85) comment = "목표에 매우 적합한 식단입니다.";
        else if (score >= 70) comment = "비교적 적합한 식단입니다.";
        else if (score >= 50) comment = "보통 수준의 식단입니다.";
        else comment = "개선이 필요한 식단입니다.";

        return new AnalysisResult(calories, protein, carbs, fat, score, comment);
    }

    private double scoreOne(double actual, double target, double weight) {
        return Math.max(0, 100 - Math.abs(actual - target) * weight);
    }
}
