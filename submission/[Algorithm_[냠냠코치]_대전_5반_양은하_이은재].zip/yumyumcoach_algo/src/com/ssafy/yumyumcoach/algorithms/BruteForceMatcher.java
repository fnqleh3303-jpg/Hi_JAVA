package com.ssafy.yumyumcoach.algorithms;

public class BruteForceMatcher {
    public static boolean contains(String text, String pattern) {
        if (text == null || pattern == null) return false;
        if (pattern.isEmpty()) return true;
        if (text.length() < pattern.length()) return false;

        for (int i = 0; i <= text.length() - pattern.length(); i++) {
            int j = 0;
            while (j < pattern.length() && text.charAt(i + j) == pattern.charAt(j)) {
                j++;
            }
            if (j == pattern.length()) {
                return true;
            }
        }
        return false;
    }
}
