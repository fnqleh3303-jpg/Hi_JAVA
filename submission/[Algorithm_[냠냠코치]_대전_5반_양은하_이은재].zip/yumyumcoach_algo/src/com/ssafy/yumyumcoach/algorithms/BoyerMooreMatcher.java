package com.ssafy.yumyumcoach.algorithms;

import java.util.Arrays;

public class BoyerMooreMatcher {
    private static final int ALPHABET_SIZE = 65536;

    public static boolean contains(String text, String pattern) {
        if (text == null || pattern == null) return false;
        int n = text.length();
        int m = pattern.length();
        if (m == 0) return true;
        if (n < m) return false;

        int[] badChar = buildBadCharTable(pattern);
        int shift = 0;

        while (shift <= n - m) {
            int j = m - 1;
            while (j >= 0 && pattern.charAt(j) == text.charAt(shift + j)) {
                j--;
            }
            if (j < 0) {
                return true;
            }
            shift += Math.max(1, j - badChar[text.charAt(shift + j)]);
        }
        return false;
    }

    private static int[] buildBadCharTable(String pattern) {
        int[] badChar = new int[ALPHABET_SIZE];
        Arrays.fill(badChar, -1);
        for (int i = 0; i < pattern.length(); i++) {
            badChar[pattern.charAt(i)] = i;
        }
        return badChar;
    }
}
