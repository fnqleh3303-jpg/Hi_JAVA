package com.ssafy.yumyumcoach.algorithms;

public class RabinKarpMatcher {
    private static final int BASE = 256;
    private static final int MOD = 101_111;

    public static boolean contains(String text, String pattern) {
        if (text == null || pattern == null) return false;
        int n = text.length();
        int m = pattern.length();
        if (m == 0) return true;
        if (n < m) return false;

        int patternHash = 0;
        int textHash = 0;
        int highestPow = 1;

        for (int i = 0; i < m - 1; i++) {
            highestPow = (highestPow * BASE) % MOD;
        }

        for (int i = 0; i < m; i++) {
            patternHash = (BASE * patternHash + pattern.charAt(i)) % MOD;
            textHash = (BASE * textHash + text.charAt(i)) % MOD;
        }

        for (int i = 0; i <= n - m; i++) {
            if (patternHash == textHash) {
                int j = 0;
                while (j < m && text.charAt(i + j) == pattern.charAt(j)) {
                    j++;
                }
                if (j == m) return true;
            }
            if (i < n - m) {
                textHash = (BASE * (textHash - text.charAt(i) * highestPow) + text.charAt(i + m)) % MOD;
                if (textHash < 0) textHash += MOD;
            }
        }
        return false;
    }
}
