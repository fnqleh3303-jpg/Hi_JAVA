package com.ssafy.yumyumcoach.domain;

public class CommunityPost {
    private int id;
    private String title;
    private String content;
    private String author;
    private String date;
    private String category;

    public CommunityPost(int id, String title, String content, String author, String date, String category) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.author = author;
        this.date = date;
        this.category = category;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getAuthor() { return author; }
    public String getDate() { return date; }
    public String getCategory() { return category; }

    @Override
    public String toString() {
        return String.format("[%d] %s | %s | %s | %s", id, title, author, category, date);
    }
}
