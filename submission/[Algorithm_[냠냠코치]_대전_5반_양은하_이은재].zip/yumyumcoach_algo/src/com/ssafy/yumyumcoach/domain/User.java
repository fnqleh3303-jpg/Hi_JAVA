package com.ssafy.yumyumcoach.domain;

public class User {
    private String userId;
    private String password;
    private String name;
    private double height;
    private double weight;
    private GoalType goalType;
    private boolean active;

    public User(String userId, String password, String name, double height, double weight, GoalType goalType) {
        this.userId = userId;
        this.password = password;
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.goalType = goalType;
        this.active = true;
    }

    public String getUserId() { return userId; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getHeight() { return height; }
    public void setHeight(double height) { this.height = height; }
    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; }
    public GoalType getGoalType() { return goalType; }
    public void setGoalType(GoalType goalType) { this.goalType = goalType; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    @Override
    public String toString() {
        return "아이디: " + userId + "\n이름: " + name + "\n키: " + height + "cm\n몸무게: " + weight
                + "kg\n목표: " + goalType.getLabel() + "\n상태: " + (active ? "활성" : "비활성");
    }
}
