package com.ssafy.yumyumcoach.domain;

public enum GoalType {
    DIET("다이어트"), BALANCE("균형식"), BULKUP("벌크업");

    private final String label;

    GoalType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    public static GoalType fromNumber(int n) {
        switch (n) {
            case 1:
                return DIET;
            case 2:
                return BALANCE;
            case 3:
                return BULKUP;
            default:
                return BALANCE;
        }
    }
}
