package com.ssafy.yumyumcoach.domain;

public class Food {
    private int foodId;
    private String foodName;
    private double calories;
    private double protein;
    private double carbs;
    private double fat;

    public Food(int foodId, String foodName, double calories, double protein, double carbs, double fat) {
        this.foodId = foodId;
        this.foodName = foodName;
        this.calories = calories;
        this.protein = protein;
        this.carbs = carbs;
        this.fat = fat;
    }

    public int getFoodId() { return foodId; }
    public String getFoodName() { return foodName; }
    public double getCalories() { return calories; }
    public double getProtein() { return protein; }
    public double getCarbs() { return carbs; }
    public double getFat() { return fat; }

    @Override
    public String toString() {
        return String.format("[%d] %s (kcal: %.0f, 단백질: %.0fg, 탄수화물: %.0fg, 지방: %.0fg)",
                foodId, foodName, calories, protein, carbs, fat);
    }
}
