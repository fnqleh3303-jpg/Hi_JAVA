package com.ssafy.yumyumcoach.domain;

public class AnalysisResult {
    private double totalCalories;
    private double totalProtein;
    private double totalCarbs;
    private double totalFat;
    private int score;
    private String comment;

    public AnalysisResult(double totalCalories, double totalProtein, double totalCarbs, double totalFat, int score,
            String comment) {
        this.totalCalories = totalCalories;
        this.totalProtein = totalProtein;
        this.totalCarbs = totalCarbs;
        this.totalFat = totalFat;
        this.score = score;
        this.comment = comment;
    }

    @Override
    public String toString() {
        return String.format(
                "총 칼로리: %.0fkcal\n총 단백질: %.0fg\n총 탄수화물: %.0fg\n총 지방: %.0fg\n점수: %d점\n평가: %s",
                totalCalories, totalProtein, totalCarbs, totalFat, score, comment);
    }
}
