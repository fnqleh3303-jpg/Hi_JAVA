package com.ssafy.yumyumcoach.domain;

import java.util.ArrayList;
import java.util.List;

public class MealRecord {
    private int mealId;
    private String userId;
    private String date;
    private String mealType;
    private List<MealItem> items;

    public MealRecord(int mealId, String userId, String date, String mealType, List<MealItem> items) {
        this.mealId = mealId;
        this.userId = userId;
        this.date = date;
        this.mealType = mealType;
        this.items = new ArrayList<>(items);
    }

    public int getMealId() { return mealId; }
    public String getUserId() { return userId; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public String getMealType() { return mealType; }
    public void setMealType(String mealType) { this.mealType = mealType; }
    public List<MealItem> getItems() { return items; }
    public void setItems(List<MealItem> items) { this.items = new ArrayList<>(items); }

    @Override
    public String toString() {
        return String.format("식단ID: %d | 날짜: %s | 식사구분: %s | 작성자: %s", mealId, date, mealType, userId);
    }
}
