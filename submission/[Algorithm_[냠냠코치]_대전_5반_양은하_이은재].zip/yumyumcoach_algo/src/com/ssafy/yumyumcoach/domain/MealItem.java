package com.ssafy.yumyumcoach.domain;

public class MealItem {
    private Food food;
    private int quantity;

    public MealItem(Food food, int quantity) {
        this.food = food;
        this.quantity = quantity;
    }

    public Food getFood() { return food; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getTotalCalories() { return food.getCalories() * quantity; }
    public double getTotalProtein() { return food.getProtein() * quantity; }
    public double getTotalCarbs() { return food.getCarbs() * quantity; }
    public double getTotalFat() { return food.getFat() * quantity; }

    @Override
    public String toString() {
        return food.getFoodName() + " x " + quantity;
    }
}
