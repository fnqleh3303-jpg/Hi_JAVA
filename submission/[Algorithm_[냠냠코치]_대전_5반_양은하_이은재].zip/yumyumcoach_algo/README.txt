YumYumCoach 알고리즘 프로젝트

실행 파일
- src/com/ssafy/yumyumcoach/Main.java

샘플 계정
- sample / 1234
- coach / 1234

미리 로드된 데이터
- sample, coach 계정
- 음식 DB 25개
- 식단 데이터 10개
- 커뮤니티 게시글 3개

적용 알고리즘
1) Brute Force
- 적용 위치: util/MenuCommandResolver
- 용도: 메뉴 번호 외에 '로그인', '식단관리', '검색' 같은 짧은 명령어를 해석
- 이유: 메뉴 후보 수가 매우 적고 문자열도 짧아서 가장 단순하고 구현 비용이 낮음

2) KMP
- 적용 위치: manager/MealManager.searchMealsByKeyword
- 용도: 식단 안의 음식명 부분 문자열 검색
- 이유: 같은 키워드로 여러 음식명을 반복 검사할 때 전처리(LPS)로 불필요한 비교를 줄이기 좋음

3) Rabin-Karp
- 적용 위치: manager/CommunityManager.searchPosts
- 용도: 게시글 제목+내용 키워드 검색
- 이유: 여러 텍스트에 대해 같은 패턴을 검사할 때 해시 기반 선별이 가능해서 시연용 비교가 명확함

4) Boyer-Moore
- 적용 위치: manager/FoodSearchManager.searchFoods
- 용도: 음식 DB 이름 검색
- 이유: 음식명이 비교적 짧지만 DB 항목을 반복 탐색할 때 실제 부분 문자열 검색에서 뒤에서부터 건너뛰며 빠르게 동작함

자료구조
- 회원: HashMap<String, User>
- 식단: LinkedHashMap<Integer, MealRecord>
- 음식 DB: LinkedHashMap<Integer, Food>
- 커뮤니티: ArrayList<CommunityPost>
- 식단 내부 음식 목록: ArrayList<MealItem>

메뉴 경로
1. 식단 검색(KMP)
- 로그인 -> 식단 관리 -> 7. 키워드 검색(KMP)
- 예시 검색어: 바나나, 고구마, 현미밥

2. 음식 DB 검색(Boyer-Moore)
- 메인 메뉴 -> 3. 음식 DB 검색(Boyer-Moore)
- 예시 검색어: 바나나, 고구마, 샐러드

3. 커뮤니티 검색(Rabin-Karp)
- 메인 메뉴 -> 4. 커뮤니티 검색(Rabin-Karp)
- 예시 검색어: 바나나, 단백질, 식단

4. 메뉴 명령어 해석(Brute Force)
- 번호 대신 '로그인', '식단관리', '회원관리', '음식검색'처럼 입력 가능
